package com.bulkmail.sender

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

data class Provider(val label: String, val host: String, val port: String)

val PROVIDERS = listOf(
    Provider("Gmail", "smtp.gmail.com", "465"),
    Provider("Yahoo", "smtp.mail.yahoo.com", "465"),
    Provider("Outlook", "smtp-mail.outlook.com", "587"),
    Provider("آخر", "", "587")
)

data class Saved(
    val provider: Int, val host: String, val port: String,
    val email: String, val password: String, val name: String
)

/** الحساب بيتخزن مشفر على الموبايل بس. المسودة (العناوين والنص) في تخزين عادي. */
class Store(ctx: Context) {
    private val secure: SharedPreferences? = try {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "secure_account", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        null
    }
    private val draft = ctx.getSharedPreferences("draft", Context.MODE_PRIVATE)

    val canSaveAccount: Boolean get() = secure != null

    fun loadAccount(): Saved? {
        val s = secure ?: return null
        val email = s.getString("email", "") ?: ""
        if (email.isEmpty()) return null
        return Saved(
            s.getInt("provider", 0), s.getString("host", "") ?: "", s.getString("port", "465") ?: "465",
            email, s.getString("password", "") ?: "", s.getString("name", "") ?: ""
        )
    }

    fun saveAccount(a: Saved) {
        secure?.edit()
            ?.putInt("provider", a.provider)?.putString("host", a.host)?.putString("port", a.port)
            ?.putString("email", a.email)?.putString("password", a.password)?.putString("name", a.name)
            ?.apply()
    }

    fun pref(key: String): String = draft.getString(key, "") ?: ""
    fun setPref(key: String, v: String) { draft.edit().putString(key, v).apply() }

    fun forgetAccount() {
        secure?.edit()?.clear()?.apply()
    }

    fun loadDraft(): Triple<String, String, String> = Triple(
        draft.getString("r", "") ?: "", draft.getString("s", "") ?: "", draft.getString("b", "") ?: ""
    )

    fun saveDraft(r: String, s: String, b: String) {
        draft.edit().putString("r", r).putString("s", s).putString("b", b).apply()
    }
}
