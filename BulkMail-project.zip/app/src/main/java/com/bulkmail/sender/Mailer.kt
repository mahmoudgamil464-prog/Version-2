package com.bulkmail.sender

import java.io.ByteArrayOutputStream
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.URL
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.Properties
import javax.activation.CommandMap
import javax.activation.DataHandler
import javax.activation.MailcapCommandMap
import javax.mail.AuthenticationFailedException
import javax.mail.Message
import javax.mail.MessagingException
import javax.mail.SendFailedException
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart
import javax.mail.internet.MimeUtility
import javax.mail.util.ByteArrayDataSource

data class Account(val host: String, val port: Int, val email: String, val password: String, val senderName: String)
data class Attach(val name: String, val mime: String, val bytes: ByteArray)
data class Recipient(val email: String, val name: String)

object Parse {
    private val EMAIL = Regex("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}")

    data class Result(val good: List<Recipient>, val bad: List<String>, val dups: Int)

    /** كل سطر: email  أو  email,اسم  أو  اسم <email>. الاسم بيستخدم مكان {name} في الرسالة. */
    fun recipients(raw: String): Result {
        val seen = HashSet<String>()
        val good = ArrayList<Recipient>()
        val bad = ArrayList<String>()
        var dups = 0
        fun add(email: String, name: String) {
            if (seen.add(email.lowercase())) {
                good.add(Recipient(email, name.ifBlank { email.substringBefore('@') }))
            } else dups++
        }
        for (line in raw.split('\n', ';').map { it.trim() }.filter { it.isNotEmpty() }) {
            val found = EMAIL.findAll(line).map { it.value }.toList()
            when {
                found.isEmpty() -> bad.add(line)
                found.size == 1 -> add(found[0], line.replace(found[0], " ").replace(Regex("[<>,\"']"), " ").trim())
                else -> found.forEach { add(it, "") }
            }
        }
        return Result(good, bad, dups)
    }
}

interface MailSender {
    fun send(r: Recipient, subject: String, body: String, files: List<Attach>)
    fun close()
}

private fun ensureMailcap() {
    val mc = CommandMap.getDefaultCommandMap() as MailcapCommandMap
    mc.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html")
    mc.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml")
    mc.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain")
    mc.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed")
    mc.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822")
    CommandMap.setDefaultCommandMap(mc)
    Thread.currentThread().contextClassLoader = MailSender::class.java.classLoader
}

private fun buildMime(
    session: Session, from: InternetAddress, r: Recipient,
    subject: String, body: String, files: List<Attach>
): MimeMessage {
    val msg = MimeMessage(session)
    msg.setFrom(from)
    msg.setRecipient(Message.RecipientType.TO, InternetAddress(r.email))
    msg.setSubject(subject, "UTF-8")
    val mp = MimeMultipart()
    val text = MimeBodyPart()
    text.setText(body, "UTF-8")
    mp.addBodyPart(text)
    for (a in files) {
        val part = MimeBodyPart()
        part.dataHandler = DataHandler(ByteArrayDataSource(a.bytes, a.mime))
        part.fileName = MimeUtility.encodeText(a.name, "UTF-8", "B")
        mp.addBodyPart(part)
    }
    msg.setContent(mp)
    msg.saveChanges()
    return msg
}

private fun fromAddress(email: String, name: String): InternetAddress =
    if (name.isBlank()) InternetAddress(email) else InternetAddress(email, name, "UTF-8")

/** إرسال عن طريق SMTP بكلمة مرور تطبيق. */
class Mailer(private val acc: Account) : MailSender {
    private val session: Session
    private var transport: Transport? = null

    init {
        ensureMailcap()
        val p = Properties()
        p["mail.smtp.host"] = acc.host
        p["mail.smtp.port"] = acc.port.toString()
        p["mail.smtp.auth"] = "true"
        if (acc.port == 465) p["mail.smtp.ssl.enable"] = "true" else p["mail.smtp.starttls.enable"] = "true"
        p["mail.smtp.connectiontimeout"] = "20000"
        p["mail.smtp.timeout"] = "30000"
        p["mail.smtp.writetimeout"] = "60000"
        session = Session.getInstance(p)
    }

    private fun open() {
        val t = session.getTransport("smtp")
        t.connect(acc.host, acc.port, acc.email, acc.password)
        transport = t
    }

    override fun send(r: Recipient, subject: String, body: String, files: List<Attach>) {
        if (transport?.isConnected != true) open()
        val msg = buildMime(session, fromAddress(acc.email, acc.senderName), r, subject, body, files)
        transport!!.sendMessage(msg, msg.allRecipients)
    }

    override fun close() {
        try { transport?.close() } catch (_: Exception) { }
    }
}

/** إرسال عن طريق Gmail API بعد تسجيل الدخول بحساب Google (من غير كلمة مرور). */
class GmailApiSender(
    private val fromEmail: String,
    private val senderName: String,
    initialToken: String?,
    private val refreshToken: () -> String?
) : MailSender {
    private val session: Session
    private var token: String? = initialToken

    init {
        ensureMailcap()
        session = Session.getInstance(Properties())
    }

    private fun post(t: String, bytes: ByteArray): Pair<Int, String> {
        val c = URL("https://gmail.googleapis.com/upload/gmail/v1/users/me/messages/send?uploadType=media")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 20000
            c.readTimeout = 90000
            c.setRequestProperty("Authorization", "Bearer $t")
            c.setRequestProperty("Content-Type", "message/rfc822")
            c.outputStream.use { it.write(bytes) }
            val code = c.responseCode
            val txt = (if (code >= 400) c.errorStream else c.inputStream)
                ?.bufferedReader()?.readText()?.take(300) ?: ""
            return code to txt
        } finally {
            c.disconnect()
        }
    }

    override fun send(r: Recipient, subject: String, body: String, files: List<Attach>) {
        val msg = buildMime(session, fromAddress(fromEmail, senderName), r, subject, body, files)
        val bos = ByteArrayOutputStream()
        msg.writeTo(bos)
        val bytes = bos.toByteArray()
        var t = token ?: refreshToken() ?: throw AuthenticationFailedException("انتهت جلسة Google، سجّل الدخول من جديد")
        var res = post(t, bytes)
        if (res.first == 401) {
            t = refreshToken() ?: throw AuthenticationFailedException("انتهت جلسة Google، سجّل الدخول من جديد")
            res = post(t, bytes)
        }
        token = t
        if (res.first !in 200..299) throw MessagingException("Gmail API ${res.first}: ${res.second}")
    }

    override fun close() { }
}

fun explain(e: Throwable): String {
    val m = e.message ?: ""
    return when {
        e is AuthenticationFailedException -> "فشل تسجيل الدخول: ${m.lineSequence().firstOrNull().orEmpty().take(110).ifBlank { "راجع الحساب" }}"
        e is SendFailedException && !e.invalidAddresses.isNullOrEmpty() -> "السيرفر رفض العنوان (غير موجود أو غير صالح)"
        generateSequence(e) { it.cause }.any { it is UnknownHostException || it is ConnectException || it is SocketTimeoutException } ->
            "مشكلة في الاتصال بالإنترنت أو بالسيرفر"
        m.contains("limit", true) || m.contains("5.4.5") -> "وصلت للحد اليومي للإرسال من هذا الحساب"
        else -> m.lineSequence().firstOrNull()?.take(140)?.ifBlank { null } ?: "خطأ غير معروف"
    }
}

/** أخطاء لو حصلت مفيش فايدة نكمل بعدها (الحساب نفسه فيه مشكلة). */
fun isFatal(e: Throwable): Boolean =
    e is AuthenticationFailedException || (e.message ?: "").let {
        it.contains("limit", true) || it.contains("5.4.5") || it.contains("Gmail API 403") || it.contains("Gmail API 401")
    }
