package com.bulkmail.sender

import android.content.Context
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

fun authRequest(): AuthorizationRequest = AuthorizationRequest.builder()
    .setRequestedScopes(
        listOf(
            Scope("https://www.googleapis.com/auth/gmail.send"),
            Scope("https://www.googleapis.com/auth/userinfo.email")
        )
    )
    .build()

/** توكن جديد بدون شاشات لو المستخدم وافق قبل كده. بيرجع null لو لازم يسجل دخول من جديد. لازم يتنادى من thread خلفي. */
fun silentToken(ctx: Context): String? = try {
    val r = Tasks.await(Identity.getAuthorizationClient(ctx).authorize(authRequest()))
    if (r.hasResolution()) null else r.accessToken
} catch (e: Exception) {
    null
}

fun fetchEmail(token: String): String? = try {
    val c = URL("https://www.googleapis.com/oauth2/v3/userinfo").openConnection() as HttpURLConnection
    c.setRequestProperty("Authorization", "Bearer $token")
    c.connectTimeout = 15000
    c.readTimeout = 15000
    val txt = c.inputStream.bufferedReader().readText()
    JSONObject(txt).optString("email").ifBlank { null }
} catch (e: Exception) {
    null
}
