package com.bulkmail.sender

import android.app.Application
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class Status { PENDING, SENDING, SENT, FAILED }

data class Item(val r: Recipient, val status: Status = Status.PENDING, val error: String = "")

private val DOC_TYPES = arrayOf(
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-powerpoint",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "text/plain",
    "image/*"
)

private const val MAX_BYTES = 20L * 1024 * 1024

class MainVM(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    val canSave = store.canSaveAccount

    var provider by mutableStateOf(0)
    var host by mutableStateOf("smtp.gmail.com")
    var port by mutableStateOf("465")
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var senderName by mutableStateOf("")
    var mode by mutableStateOf(0) // 0 = حساب Google، 1 = كلمة مرور تطبيق
    var googleEmail by mutableStateOf("")
    private var token: String? = null

    var recipients by mutableStateOf("")
    var subject by mutableStateOf("")
    var body by mutableStateOf("")
    var delaySec by mutableStateOf(3f)

    var files by mutableStateOf(listOf<Attach>())
    var items by mutableStateOf(listOf<Item>())
    var sending by mutableStateOf(false)
    var banner by mutableStateOf<String?>(null)
    private var job: Job? = null

    init {
        store.loadAccount()?.let {
            provider = it.provider; host = it.host; port = it.port
            email = it.email; password = it.password; senderName = it.name
        }
        store.pref("sname").let { if (it.isNotBlank()) senderName = it }
        mode = store.pref("mode").toIntOrNull() ?: 0
        googleEmail = store.pref("gemail")
        val (r, s, b) = store.loadDraft()
        recipients = r; subject = s; body = b
    }

    fun setMode(i: Int) { mode = i; store.setPref("mode", i.toString()) }

    fun setSender(v: String) { senderName = v; store.setPref("sname", v) }

    fun onAuth(r: AuthorizationResult) {
        token = r.accessToken
        val t = token ?: run { banner = "ما وصلش توكن من Google"; return }
        viewModelScope.launch(Dispatchers.IO) {
            val e = fetchEmail(t)
            if (e != null) {
                googleEmail = e; store.setPref("gemail", e); banner = "تم تسجيل الدخول: $e"
            } else banner = "تم الإذن لكن تعذر معرفة البريد، جرّب تاني"
        }
    }

    fun signOut() { token = null; googleEmail = ""; store.setPref("gemail", "") }

    fun pickProvider(i: Int) {
        provider = i
        if (i < PROVIDERS.size - 1) { host = PROVIDERS[i].host; port = PROVIDERS[i].port }
    }

    fun saveAccount() {
        if (!canSave) { banner = "التخزين الآمن مش متاح على الجهاز ده. هتكتب كلمة المرور كل مرة."; return }
        store.saveAccount(Saved(provider, host.trim(), port.trim(), email.trim(), password, senderName.trim()))
        banner = "تم حفظ الحساب على الموبايل"
    }

    fun forgetAccount() {
        store.forgetAccount(); email = ""; password = ""; senderName = ""
        banner = "تم مسح الحساب"
    }

    fun setDraft(r: String = recipients, s: String = subject, b: String = body) {
        recipients = r; subject = s; body = b
        store.saveDraft(r, s, b)
    }

    private fun nameOf(uri: Uri): String {
        val cr = getApplication<Application>().contentResolver
        cr.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return uri.lastPathSegment ?: "file"
    }

    fun addFiles(uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            val cr = getApplication<Application>().contentResolver
            var list = files
            for (u in uris) {
                try {
                    val bytes = cr.openInputStream(u)?.use { it.readBytes() } ?: continue
                    val total = list.sumOf { it.bytes.size.toLong() } + bytes.size
                    if (total > MAX_BYTES) { banner = "إجمالي المرفقات لازم يكون أقل من 20 MB"; continue }
                    list = list + Attach(nameOf(u), cr.getType(u) ?: "application/octet-stream", bytes)
                } catch (e: Exception) {
                    banner = "تعذر قراءة ملف"
                }
            }
            files = list
        }
    }

    fun removeFile(i: Int) { files = files.toMutableList().also { it.removeAt(i) } }

    fun importList(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val t = getApplication<Application>().contentResolver.openInputStream(uri)
                    ?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return@launch
                setDraft(r = (recipients.trim() + "\n" + t).trim())
            } catch (e: Exception) {
                banner = "تعذر قراءة الملف"
            }
        }
    }

    private fun account(): Account? {
        val p = port.trim().toIntOrNull() ?: return null
        if (email.isBlank() || password.isBlank() || host.isBlank()) return null
        return Account(host.trim(), p, email.trim(), password.replace(" ", ""), senderName.trim())
    }

    private fun mark(i: Int, s: Status, err: String = "") {
        items = items.toMutableList().also { it[i] = it[i].copy(status = s, error = err) }
    }

    fun start(fresh: Boolean, want: Status = Status.PENDING) {
        if (sending) return
        val ctx = getApplication<Application>()
        val acc: Account? = if (mode == 0) null else (account() ?: run { banner = "اكتب البريد وكلمة مرور التطبيق في قسم الحساب"; return })
        if (mode == 0 && googleEmail.isBlank()) { banner = "سجّل الدخول بحساب Google أولًا"; return }
        if (subject.isBlank() && body.isBlank()) { banner = "اكتب الموضوع أو نص الرسالة"; return }
        if (fresh) {
            val p = Parse.recipients(recipients).good
            if (p.isEmpty()) { banner = "أضف عنوان صحيح واحد على الأقل"; return }
            items = p.map { Item(it) }
        }
        val targets = items.indices.filter { items[it].status == want }
        if (targets.isEmpty()) return
        val subj = subject; val txt = body; val fs = files; val gap = delaySec
        val gEmail = googleEmail; val gName = senderName; val tok = token
        sending = true; banner = null
        job = viewModelScope.launch(Dispatchers.IO) {
            val mailer: MailSender =
                if (acc == null) GmailApiSender(gEmail, gName, tok) { silentToken(ctx).also { token = it } }
                else Mailer(acc)
            try {
                for ((k, i) in targets.withIndex()) {
                    if (!isActive) break
                    mark(i, Status.SENDING)
                    val r = items[i].r
                    try {
                        mailer.send(r, subj.replace("{name}", r.name), txt.replace("{name}", r.name), fs)
                        mark(i, Status.SENT)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        mark(i, Status.FAILED, explain(e))
                        if (isFatal(e)) { banner = explain(e) + " — توقف الإرسال"; break }
                    }
                    if (k < targets.size - 1 && gap > 0f) delay((gap * 1000).toLong() + Random.nextLong(0, 800))
                }
            } finally {
                mailer.close()
                sending = false
            }
        }
    }

    fun cancel() { job?.cancel(); banner = "تم إيقاف الإرسال" }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App() }
    }
}

@Composable
fun App(vm: MainVM = viewModel()) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF3FC1AD), onPrimary = Color(0xFF06201C),
        background = Color(0xFF0F1B19), onBackground = Color(0xFFE6F2EF),
        surface = Color(0xFF172725), onSurface = Color(0xFFE6F2EF)
    ) else lightColorScheme(
        primary = Color(0xFF0B6B5F), onPrimary = Color.White,
        background = Color(0xFFEEF3F1), onBackground = Color(0xFF16302D),
        surface = Color.White, onSurface = Color(0xFF16302D)
    )
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Screen(vm)
            }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
fun Field(
    value: String, onChange: (String) -> Unit, label: String,
    ltr: Boolean = false, minLines: Int = 1, hide: Boolean = false,
    kb: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        minLines = minLines,
        textStyle = LocalTextStyle.current.copy(textDirection = if (ltr) TextDirection.Ltr else TextDirection.Content),
        visualTransformation = if (hide) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = kb)
    )
}

@Composable
fun Screen(vm: MainVM) {
    val parsed = remember(vm.recipients) { Parse.recipients(vm.recipients) }
    var showPass by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val clip = LocalClipboardManager.current
    val uri = LocalUriHandler.current
    val view = LocalView.current
    DisposableEffect(vm.sending) {
        view.keepScreenOn = vm.sending
        onDispose { }
    }
    val ctx = LocalContext.current
    val authLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        try {
            vm.onAuth(Identity.getAuthorizationClient(ctx).getAuthorizationResultFromIntent(res.data))
        } catch (e: Exception) {
            vm.banner = "تم إلغاء تسجيل الدخول"
        }
    }
    val signIn: () -> Unit = {
        Identity.getAuthorizationClient(ctx).authorize(authRequest())
            .addOnSuccessListener { r ->
                val pi = r.pendingIntent
                if (r.hasResolution() && pi != null) authLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                else vm.onAuth(r)
            }
            .addOnFailureListener { vm.banner = "فشل تسجيل الدخول: ${it.message ?: ""}" }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.addFiles(it) }
    val pickList = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importList(u) }

    val sent = vm.items.count { it.status == Status.SENT }
    val failed = vm.items.count { it.status == Status.FAILED }
    val pending = vm.items.count { it.status == Status.PENDING }

    LazyColumn(
        modifier = Modifier.statusBarsPadding().navigationBarsPadding().imePadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("مرسل الإيميلات", style = MaterialTheme.typography.headlineSmall)
            Text("رسالة منفصلة لكل شخص، بالمرفقات، من حسابك مباشرة.", style = MaterialTheme.typography.bodyMedium)
        }
        vm.banner?.let { b ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(b, Modifier.weight(1f), color = MaterialTheme.colorScheme.onPrimary)
                        TextButton(onClick = { vm.banner = null }) { Text("إغلاق", color = MaterialTheme.colorScheme.onPrimary) }
                    }
                }
            }
        }
        item {
            Section("1) حساب الإرسال") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = vm.mode == 0, onClick = { vm.setMode(0) }, label = { Text("حساب Google") })
                    FilterChip(selected = vm.mode == 1, onClick = { vm.setMode(1) }, label = { Text("كلمة مرور تطبيق") })
                }
                if (vm.mode == 0) {
                    if (vm.googleEmail.isBlank()) {
                        Button(onClick = { signIn() }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الدخول بحساب Google") }
                    } else {
                        Text("مسجّل بحساب: ${vm.googleEmail}", style = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { signIn() }) { Text("تغيير الحساب") }
                            TextButton(onClick = { vm.signOut() }) { Text("تسجيل خروج") }
                        }
                    }
                    Field(vm.senderName, { vm.setSender(it) }, "اسم المرسل (اختياري)")
                    Text("بيطلب إذن إرسال الإيميلات فقط، ومش بيقرا رسايلك.", style = MaterialTheme.typography.bodySmall)
                } else {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PROVIDERS.forEachIndexed { i, p ->
                            FilterChip(selected = vm.provider == i, onClick = { vm.pickProvider(i) }, label = { Text(p.label) })
                        }
                    }
                    if (vm.provider == PROVIDERS.size - 1) {
                        Field(vm.host, { vm.host = it }, "سيرفر SMTP", ltr = true)
                        Field(vm.port, { vm.port = it }, "المنفذ (465 أو 587)", ltr = true, kb = KeyboardType.Number)
                    }
                    Field(vm.email, { vm.email = it }, "بريدك", ltr = true, kb = KeyboardType.Email)
                    Field(vm.password, { vm.password = it }, "كلمة مرور التطبيق", ltr = true, hide = !showPass)
                    Field(vm.senderName, { vm.setSender(it) }, "اسم المرسل (اختياري)")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.saveAccount() }) { Text("حفظ الحساب") }
                        OutlinedButton(onClick = { showPass = !showPass }) { Text(if (showPass) "إخفاء" else "إظهار") }
                        TextButton(onClick = { vm.forgetAccount() }) { Text("مسح") }
                    }
                    Text(
                        "Gmail مش بيقبل كلمة مرور حسابك العادية. فعّل التحقق بخطوتين ثم أنشئ «كلمة مرور تطبيق».",
                        style = MaterialTheme.typography.bodySmall
                    )
                    TextButton(onClick = { uri.openUri("https://myaccount.google.com/apppasswords") }) { Text("فتح صفحة كلمات مرور التطبيقات") }
                }
            }
        }
        item {
            Section("2) المستلمين") {
                Field(vm.recipients, { vm.setDraft(r = it) }, "عنوان في كل سطر", ltr = true, minLines = 5, kb = KeyboardType.Email)
                Text(
                    "${parsed.good.size} عنوان صحيح" +
                        (if (parsed.dups > 0) " • ${parsed.dups} مكرر اتشال" else "") +
                        (if (parsed.bad.isNotEmpty()) " • ${parsed.bad.size} غير صحيح" else ""),
                    style = MaterialTheme.typography.bodySmall
                )
                if (parsed.bad.isNotEmpty()) {
                    Text(parsed.bad.take(5).joinToString("، "), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pickList.launch(arrayOf("text/*", "application/csv", "application/vnd.ms-excel")) }) { Text("استيراد من ملف") }
                    OutlinedButton(onClick = { clip.getText()?.let { vm.setDraft(r = (vm.recipients.trim() + "\n" + it.text).trim()) } }) { Text("لصق") }
                }
                Text("نصيحة: اكتب «email,اسم» وهتقدر تستخدم {name} في الرسالة لتخصيص الاسم.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            Section("3) الرسالة") {
                Field(vm.subject, { vm.setDraft(s = it) }, "الموضوع")
                Field(vm.body, { vm.setDraft(b = it) }, "نص الرسالة", minLines = 6)
            }
        }
        item {
            Section("4) المرفقات") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { pickFiles.launch(DOC_TYPES) }) { Text("+ PDF / Word / Excel / صور") }
                    OutlinedButton(onClick = { pickFiles.launch(arrayOf("*/*")) }) { Text("أي ملف") }
                }
                vm.files.forEachIndexed { i, f ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${f.name} (${f.bytes.size / 1024} KB)", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { vm.removeFile(i) }) { Text("حذف") }
                    }
                }
            }
        }
        item {
            Section("5) الإرسال") {
                Text("الفاصل بين الرسائل: ${vm.delaySec.toInt()} ثانية (يحميك من حظر السبام)", style = MaterialTheme.typography.bodySmall)
                Slider(value = vm.delaySec, onValueChange = { vm.delaySec = it }, valueRange = 0f..10f, steps = 9)
                if (vm.sending) {
                    LinearProgressIndicator(progress = { if (vm.items.isEmpty()) 0f else (sent + failed).toFloat() / vm.items.size }, modifier = Modifier.fillMaxWidth())
                    Text("خلي التطبيق مفتوح والشاشة شغالة لحد ما يخلص.", style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { vm.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("إيقاف") }
                } else {
                    Button(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth(), enabled = parsed.good.isNotEmpty()) { Text("ابدأ الإرسال") }
                    if (pending > 0 && sent + failed > 0) {
                        OutlinedButton(onClick = { vm.start(false, Status.PENDING) }, modifier = Modifier.fillMaxWidth()) { Text("كمّل المتبقي ($pending)") }
                    }
                    if (failed > 0) {
                        OutlinedButton(onClick = { vm.start(false, Status.FAILED) }, modifier = Modifier.fillMaxWidth()) { Text("إعادة محاولة الفاشل ($failed)") }
                        TextButton(onClick = {
                            clip.setText(AnnotatedString(vm.items.filter { it.status == Status.FAILED }.joinToString("\n") { it.r.email }))
                            vm.banner = "تم نسخ العناوين الفاشلة"
                        }) { Text("نسخ العناوين الفاشلة") }
                    }
                }
                if (vm.items.isNotEmpty()) Text("تم: $sent • فشل: $failed • متبقي: $pending")
            }
        }
        items(vm.items) { it ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
                Text(
                    when (it.status) { Status.SENT -> "✓"; Status.FAILED -> "✗"; Status.SENDING -> "…"; else -> "•" },
                    Modifier.width(24.dp),
                    color = if (it.status == Status.FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
                Column {
                    Text(it.r.email, style = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr))
                    if (it.error.isNotEmpty()) Text(it.error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("تأكيد الإرسال") },
            text = { Text("هيتبعت ${parsed.good.size} رسالة منفصلة من ${(if (vm.mode == 0) vm.googleEmail else vm.email).ifBlank { "حسابك" }}، ومعاها ${vm.files.size} مرفق. تكمل؟") },
            confirmButton = { TextButton(onClick = { confirm = false; vm.start(true) }) { Text("ابعت") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
        )
    }
}
